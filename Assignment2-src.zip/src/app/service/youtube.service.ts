import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class YoutubeService {

  constructor(private http: HttpClient) { }

  //this method will make HTTP request
  getChannels(channelName: string): Observable<any> {

    //this will return channel only (need to use our own API youtube token)
    const url = "https://www.googleapis.com/youtube/v3/search?part=snippet&q=" +
    channelName + "&type=channel&key=AIzaSyCZx_-E1ARika6EaleD8u491ceuLiTlhYQ" + "&maxResults=21"

    return this.http.get<any>(url)
  }
}
